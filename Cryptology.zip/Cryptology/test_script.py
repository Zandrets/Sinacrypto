#from random import randbytes
#print(len(randbytes(32)))
#file=open("texto de leer.txt", "rt").read()
#file.close()
#print(file)
from time import time, ctime

tiempo=time()
print(type(ctime(tiempo)))